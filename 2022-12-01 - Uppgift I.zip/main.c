/********************************************************************************
* main.c: Implementering av ett system inneh�llande PWM-generering f�r styrning
*         av tv� lysdioder via l�sning av analoga insignaler fr�n potentiometrar,
*         vilket AD-omvandlas.
*
*         Tv� lysdioder anslutna till pin 8 - 9 (PORTB0 - PORTB1) styrs via tv�
*         potentiometrar anslutna till analoga pinnar A0 - A1 (PORTC0 - PORTC1)
*         enligt nedan:
*
*         1. Potentiometern ansluten till analog pin A0 (PORTC0) kontrollerar 
*            ljusstyrkan p� lysdioden ansluten till pin 8 (PORTB0).
*         2. Potentiometern ansluten till analog pin A1 (PORTC1) kontrollerar 
*            ljusstyrkan p� lysdioden ansluten till pin 9 (PORTB1).
********************************************************************************/
#include "header.h"

/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt AD-omvandlare.
********************************************************************************/
void setup(void)
{
   DDRB = (1 << LED1) | (1 << LED2);
   (void)adc_read(POT1);
   return;
}

/********************************************************************************
* main: Initierar mikrodatorn vid start. Lysdioderna styrs kontinuerligt med
*       PWM-generering en i taget med en periodtid p� 1000 us.
********************************************************************************/
int main(void)
{
   setup();

   while (1)
   {
      pwm_run(POT1, LED1, 1000); 
      pwm_run(POT2, LED2, 1000); 
   }

   return 0;
}

